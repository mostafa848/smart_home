import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_home/models/app_memory.dart';
import 'package:smart_home/wifi_service/wifi_change.dart';
import 'package:smart_home/wifi_service/wifi_service.dart';

part 'control_state.dart';

class ControlCubit extends Cubit<ControlState> {
  static const Duration _reconnectDelay = Duration(seconds: 3);

  final WiFiService _wifiService = WiFiService();
  final WifiChangeService _wifiChangeService = WifiChangeService();
  final AppMemory _appMemory = AppMemory();

  Timer? _reconnectTimer;
  bool _manualDisconnect = false;
  int _reconnectAttempts = 0;

  ControlCubit() : super(const ControlState()) {
    _wifiService.onJsonMessage = _handleMessage;
    _wifiService.onConnectionClosed = _handleConnectionClosed;
  }

  Future<bool> connectWiFi(
    String ip,
    int port, {
    String ssid = '',
    String password = '',
    bool isReconnect = false,
  }) async {
    _reconnectTimer?.cancel();
    _manualDisconnect = false;

    emit(
      state.copyWith(
        status: isReconnect
            ? ConnectionStatus.reconnecting
            : ConnectionStatus.connecting,
        errorMessage: null,
        retryCount: isReconnect ? _reconnectAttempts : 0,
      ),
    );

    try {
      if (ssid.trim().isNotEmpty) {
        await _wifiChangeService.ensureConnected(
          ssid: ssid,
          password: password,
        );
      }

      await _wifiService.connect(ip, port, ssid, password);
      await _appMemory.saveConnectionInfo(
        ip,
        port,
        ssid: ssid,
        password: password,
      );

      _reconnectAttempts = 0;
      emit(
        state.copyWith(
          status: ConnectionStatus.connected,
          errorMessage: null,
          retryCount: 0,
        ),
      );
      return true;
    } catch (e) {
      final message = _formatErrorMessage(e);

      if (isReconnect) {
        _scheduleReconnect(message);
      } else {
        emit(
          state.copyWith(
            status: ConnectionStatus.disconnected,
            errorMessage: message,
            retryCount: 0,
          ),
        );
      }

      return false;
    }
  }

  Future<void> reconnectToLastConnection() async {
    try {
      final connectionInfo = await _appMemory.getConnectionInfo();

      if (connectionInfo == null) {
        return;
      }

      final ip = connectionInfo['ip'] as String;
      final port = connectionInfo['port'] as int;
      final ssid = connectionInfo['ssid'] as String? ?? '';
      final password = connectionInfo['password'] as String? ?? '';

      await connectWiFi(
        ip,
        port,
        ssid: ssid,
        password: password,
        isReconnect: true,
      );
    } catch (e) {
      emit(
        state.copyWith(
          status: ConnectionStatus.disconnected,
          errorMessage: _formatErrorMessage(e),
        ),
      );
    }
  }

  Future<void> disconnect() async {
    _manualDisconnect = true;
    _reconnectTimer?.cancel();
    _reconnectAttempts = 0;
    await _wifiService.disconnect();
    await _wifiChangeService.disableWifiUsage();

    emit(
      state.copyWith(
        status: ConnectionStatus.disconnected,
        errorMessage: null,
        retryCount: 0,
      ),
    );
  }

  void sendCommand(Map<String, dynamic> command) {
    if (state.status != ConnectionStatus.connected) {
      return;
    }

    final roomName = command['room']?.toString();
    final deviceName = command['device']?.toString();
    final isOn = _coerceBool(command['state'] ?? command['status']);

    if (roomName != null && deviceName != null && isOn != null) {
      syncDeviceState(roomName: roomName, deviceName: deviceName, isOn: isOn);
    }

    _wifiService.send(command);
  }

  bool? getDeviceState(String roomName, String deviceName) {
    return state.deviceStates[_deviceStateKey(roomName, deviceName)];
  }

  void syncDeviceState({
    required String roomName,
    required String deviceName,
    required bool isOn,
  }) {
    final key = _deviceStateKey(roomName, deviceName);
    if (state.deviceStates[key] == isOn) {
      return;
    }

    final updatedStates = Map<String, bool>.from(state.deviceStates)
      ..[key] = isOn;

    emit(state.copyWith(deviceStates: updatedStates));
  }

  void _handleConnectionClosed(Object? error) {
    if (_manualDisconnect || isClosed) {
      return;
    }

    final message = error == null
        ? 'Connection lost. Trying to reconnect...'
        : 'Connection lost: ${_formatErrorMessage(error)}';

    emit(
      state.copyWith(
        status: ConnectionStatus.disconnected,
        errorMessage: message,
      ),
    );

    _scheduleReconnect(message);
  }

  void _scheduleReconnect(String message) {
    final ip = _wifiService.lastIP;
    final port = _wifiService.lastPort;
    final ssid = _wifiService.lastSSID ?? '';
    final password = _wifiService.lastPassword ?? '';

    if (_manualDisconnect || ip == null || port == null || isClosed) {
      return;
    }

    _reconnectTimer?.cancel();
    _reconnectAttempts += 1;

    emit(
      state.copyWith(
        status: ConnectionStatus.reconnecting,
        errorMessage: message,
        retryCount: _reconnectAttempts,
      ),
    );

    _reconnectTimer = Timer(_reconnectDelay, () {
      if (!_manualDisconnect && !isClosed) {
        unawaited(
          connectWiFi(
            ip,
            port,
            ssid: ssid,
            password: password,
            isReconnect: true,
          ),
        );
      }
    });
  }

  String _formatErrorMessage(Object error) {
    final message = error.toString().trim();
    if (message.startsWith('Exception: ')) {
      return message.substring('Exception: '.length);
    }
    return message;
  }

  void _handleMessage(Map<String, dynamic> message) {
    debugPrint('Message received: $message');

    if (_tryApplyDeviceStates(message)) {
      return;
    }

    final type = message['type']?.toString().toLowerCase();
    if (type == 'error') {
      emit(
        state.copyWith(
          errorMessage:
              message['message']?.toString() ?? 'Unknown device error',
        ),
      );
      return;
    }

    if (type == 'ack') {
      debugPrint('Command acknowledged by device.');
    }
  }

  bool _tryApplyDeviceStates(Map<String, dynamic> message) {
    var applied = false;

    final directUpdate = _extractDeviceUpdate(message);
    if (directUpdate != null) {
      syncDeviceState(
        roomName: directUpdate.roomName,
        deviceName: directUpdate.deviceName,
        isOn: directUpdate.isOn,
      );
      applied = true;
    }

    final payload = message['payload'];
    if (payload is Map<String, dynamic>) {
      final nestedUpdate = _extractDeviceUpdate(payload, fallback: message);
      if (nestedUpdate != null) {
        syncDeviceState(
          roomName: nestedUpdate.roomName,
          deviceName: nestedUpdate.deviceName,
          isOn: nestedUpdate.isOn,
        );
        applied = true;
      }
    }

    final devices = message['devices'];
    if (devices is List) {
      for (final item in devices) {
        if (item is! Map<String, dynamic>) continue;

        final update = _extractDeviceUpdate(item, fallback: message);
        if (update == null) continue;

        syncDeviceState(
          roomName: update.roomName,
          deviceName: update.deviceName,
          isOn: update.isOn,
        );
        applied = true;
      }
    }

    return applied;
  }

  _DeviceUpdate? _extractDeviceUpdate(
    Map<String, dynamic> data, {
    Map<String, dynamic>? fallback,
  }) {
    final type = (data['type'] ?? fallback?['type'])
        ?.toString()
        .toLowerCase()
        .trim();

    if (type == 'error') {
      return null;
    }

    final nestedDevice = data['device'];
    final deviceMap = nestedDevice is Map<String, dynamic>
        ? nestedDevice
        : null;

    final roomName =
        _readString(data, const ['room', 'roomName', 'room_name']) ??
        _readString(fallback, const ['room', 'roomName', 'room_name']);

    final deviceName =
        deviceMap?['name']?.toString() ??
        _readString(data, const ['device', 'deviceName', 'device_name']) ??
        _readString(fallback, const ['device', 'deviceName', 'device_name']);

    final isOn = _coerceBool(
      data['state'] ??
          data['status'] ??
          data['isOn'] ??
          data['value'] ??
          deviceMap?['state'] ??
          deviceMap?['status'] ??
          fallback?['state'] ??
          fallback?['status'],
    );

    if (roomName == null || deviceName == null || isOn == null) {
      return null;
    }

    return _DeviceUpdate(
      roomName: roomName,
      deviceName: deviceName,
      isOn: isOn,
    );
  }

  String? _readString(Map<String, dynamic>? data, List<String> keys) {
    if (data == null) {
      return null;
    }

    for (final key in keys) {
      final value = data[key];
      if (value is String && value.trim().isNotEmpty) {
        return value.trim();
      }
    }

    return null;
  }

  bool? _coerceBool(dynamic value) {
    if (value is bool) return value;
    if (value is num) return value != 0;
    if (value is String) {
      switch (value.trim().toLowerCase()) {
        case 'true':
        case '1':
        case 'on':
          return true;
        case 'false':
        case '0':
        case 'off':
          return false;
      }
    }

    return null;
  }

  String _deviceStateKey(String roomName, String deviceName) {
    return '${roomName.trim().toLowerCase()}::${deviceName.trim().toLowerCase()}';
  }

  @override
  Future<void> close() async {
    _manualDisconnect = true;
    _reconnectTimer?.cancel();
    await _wifiService.disconnect();
    return super.close();
  }
}

class _DeviceUpdate {
  const _DeviceUpdate({
    required this.roomName,
    required this.deviceName,
    required this.isOn,
  });

  final String roomName;
  final String deviceName;
  final bool isOn;
}
