part of 'control_cubit.dart';

enum ConnectionStatus { connecting, reconnecting, connected, disconnected }

class ControlState {
  static const Object _unset = Object();

  final ConnectionStatus status;
  final String? errorMessage;
  final int retryCount;
  final Map<String, bool> deviceStates;

  const ControlState({
    this.status = ConnectionStatus.disconnected,
    this.errorMessage,
    this.retryCount = 0,
    this.deviceStates = const {},
  });

  ControlState copyWith({
    ConnectionStatus? status,
    Object? errorMessage = _unset,
    int? retryCount,
    Object? deviceStates = _unset,
  }) {
    return ControlState(
      status: status ?? this.status,
      errorMessage: identical(errorMessage, _unset)
          ? this.errorMessage
          : errorMessage as String?,
      retryCount: retryCount ?? this.retryCount,
      deviceStates: identical(deviceStates, _unset)
          ? this.deviceStates
          : Map<String, bool>.unmodifiable(deviceStates as Map<String, bool>),
    );
  }
}
