import 'package:shared_preferences/shared_preferences.dart';

class AppMemory {
  static const String _ipKey = 'System_ip';
  static const String _portKey = 'System_port';
  static const String _ssidKey = 'System_ssid';
  static const String _passwordKey = 'System_password';

  Future<void> saveConnectionInfo(
    String ip,
    int port, {
    String ssid = '',
    String password = '',
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_ipKey, ip);
    await prefs.setInt(_portKey, port);
    await prefs.setString(_ssidKey, ssid);
    await prefs.setString(_passwordKey, password);
  }

  Future<Map<String, dynamic>?> getConnectionInfo() async {
    final prefs = await SharedPreferences.getInstance();
    final ip = prefs.getString(_ipKey);
    final port = prefs.getInt(_portKey);

    if (ip != null && port != null) {
      return {
        'ip': ip,
        'port': port,
        'ssid': prefs.getString(_ssidKey) ?? '',
        'password': prefs.getString(_passwordKey) ?? '',
      };
    }
    return null;
  }

  String? getConnectionInfoSync() {
    // للاستخدام في حالات محدودة فقط
    return null;
  }
}
