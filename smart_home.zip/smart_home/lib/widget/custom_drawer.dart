import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:smart_home/wifi_service/connection_screen.dart';
import 'package:url_launcher/url_launcher.dart';

class CustomDrawer extends StatefulWidget {
  const CustomDrawer({Key? key}) : super(key: key);

  @override
  _CustomDrawerState createState() => _CustomDrawerState();
}

class _CustomDrawerState extends State<CustomDrawer> {
  String _appVersion = 'Loading...';
  @override
  void initState() {
    super.initState();
    _loadAppVersion();
  }

  Future<void> _launchURL(String url) async {
    final Uri uri = Uri.parse(url);

    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    } else {
      throw 'Could not launch $url';
    }
  }


  Future<void> _loadAppVersion() async {
    try {
      final packageInfo = await PackageInfo.fromPlatform();
      setState(() {
        _appVersion = packageInfo.version;
      });
    } catch (e) {
      debugPrint('Error loading app version: $e');
      setState(() {
        _appVersion = 'Unknown';
      });
    }
  }

  Widget _buildDrawerItem(
    BuildContext context, {
    required IconData icon,
    required String label,
    String sublabel = "",
    required VoidCallback onTap,
  }) {
    return ListTile(
      leading: Icon(icon, color: const Color(0xFF0A6ED7), size: 20),
      title: Text("  $label", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400)),
      subtitle: Text("    $sublabel", style: TextStyle(fontSize: 8)),
      onTap: onTap,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      dense: true,
      horizontalTitleGap: 0,
    );
  }

  Widget buildCustomDrawer() {
    return Drawer(
      width: 190,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20),
          bottomLeft: Radius.circular(20),
        ),
      ),
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF0A6ED7), Color(0xFF50A8FF)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.end,
              children: const [
                Text(
                  'CoreVolt',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Technologies',
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ],
            ),
          ),
          _buildDrawerItem(
            context,
            icon: Icons.wifi,
            label: 'Connection',
            sublabel: 'Connect to System',
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const ConnectionScreen(),
                ),
              );
            },
          ),
          _buildDrawerItem(
            context,
            icon: Icons.photo_camera,
            label: 'Instagram',
            sublabel: 'corevolt_technologies',
            onTap: () {
              _launchURL(
                'https://www.instagram.com/corevolt_technologies?igsh=MXF3NTJsNWsxNGM2bA==',
              );
              Navigator.pop(context);
            },
          ),
          _buildDrawerItem(
            context,
            icon: Icons.facebook,
            label: 'Facebook',
            sublabel: 'CoreVolt Technologies',
            onTap: () {
              _launchURL('https://www.facebook.com/share/17eJxQp8TT/');
              Navigator.pop(context);
            },
          ),
          _buildDrawerItem(
            context,
            icon: Icons.email,
            label: 'Email',
            sublabel: 'corevolttechnologies@gmail.com',
            onTap: () {
              _launchURL('mailto:corevolttechnologies@gmail.com');
              Navigator.pop(context);
            },
          ),
          const Divider(height: 1),
          _buildDrawerItem(
            context,
            icon: Icons.support_agent,
            label: 'Support',
            sublabel: '+963944817849',
            onTap: () {
              _launchURL('tel:+963944817849');
              Navigator.pop(context);
            },
          ),
          _buildDrawerItem(
            context,
            icon: Icons.info_outline,
            label: 'AppVersion:$_appVersion',
            sublabel: 'SystemVersion : 1.0.0',
            onTap: () {},
          ),
          _buildDrawerItem(
            context,
            icon: Icons.copyright,
            label: 'Copyright',
            sublabel: 'CoreVolt Technologies 2026',
            onTap: () {}, // do nothing on tap
          ),
        ],
      ),
    );
  }
  
  @override
  Widget build(BuildContext context) {
    return buildCustomDrawer();
  }
}
