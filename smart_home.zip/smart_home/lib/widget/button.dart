import 'package:flutter/material.dart';

class SwitchButton extends StatelessWidget {
  final bool value;
  final bool enabled;
  final ValueChanged<bool> onChanged;
  final String deviceName;
  final String? imageOn;
  final String? imageOff;

  const SwitchButton({
    super.key,
    required this.value,
    this.enabled = true,
    required this.onChanged,
    required this.deviceName,
    this.imageOn,
    this.imageOff,
  });

  Widget _buildDeviceImage(BuildContext context) {
    final imagePath = value ? imageOn : imageOff;
    if (imagePath == null || imagePath.isEmpty) {
      return Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            value ? Icons.lightbulb : Icons.lightbulb_outline,
            color: Colors.white,
            size:
                MediaQueryData.fromView(
                  WidgetsBinding.instance.platformDispatcher.views.first,
                ).size.width *
                0.1,
          ),
          Text(
            deviceName,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.w700,
              color: const Color(0xFF83EEFF),
              fontSize:
                  MediaQueryData.fromView(
                    WidgetsBinding.instance.platformDispatcher.views.first,
                  ).size.width *
                  0.05,
            ),
          ),
        ],
      );
    }

    return Image.asset(
      imagePath,
      width:
          MediaQueryData.fromView(
            WidgetsBinding.instance.platformDispatcher.views.first,
          ).size.width *
          0.15,
      height:
          MediaQueryData.fromView(
            WidgetsBinding.instance.platformDispatcher.views.first,
          ).size.width *
          0.2,
      fit: BoxFit.cover,

      errorBuilder: (context, error, stackTrace) {
        return Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(height: 8),
            Icon(
              value ? Icons.lightbulb : Icons.lightbulb_outline,
              color: Colors.white,
              size:
                  MediaQueryData.fromView(
                    WidgetsBinding.instance.platformDispatcher.views.first,
                  ).size.width *
                  0.1,
            ),
            Text(
              deviceName,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w700,
                color: const Color(0xFF83EEFF),
                fontSize:
                    MediaQueryData.fromView(
                      WidgetsBinding.instance.platformDispatcher.views.first,
                    ).size.width *
                    0.05,
              ),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
    const activeColor = Color(0xFF55B5DC);

    return Opacity(
      key: scaffoldKey,
      opacity: enabled ? 1 : 0.7,
      child: GestureDetector(
        onTap: enabled
            ? () => onChanged(!value)
            : () => {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('انت غير متصل بالنظام\nيرجى الاتصال أولاً',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600 , color: Colors.white)
                    ),
                    duration: Duration(seconds: 2),
                    backgroundColor: activeColor,
                  ),
                ),
              },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          width: 66,
          height: 66,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: value
                ? const LinearGradient(
                    colors: [Color(0xFF83EEFF), Color(0xFF55B5DC)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  )
                : const LinearGradient(
                    colors: [Color(0xFF062F6E), Color(0xFF0D3A75)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
            border: Border.all(
              color: value ? activeColor : const Color(0xFF2A4D87),
              width: 1.6,
            ),
            boxShadow: [
              if (value)
                const BoxShadow(
                  color: Color(0x5533B5E0),
                  blurRadius: 16,
                  offset: Offset(0, 10),
                ),
            ],
          ),
          child: Center(child: _buildDeviceImage(context)),
        ),
      ),
    );
  }
}
