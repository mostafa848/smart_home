import 'package:flutter/material.dart';
import 'package:smart_home/cubit/control_cubit.dart';

class ConnectionIndicator extends StatelessWidget {
  final ConnectionStatus status;
  final int retryCount;

  const ConnectionIndicator({
    super.key,
    required this.status,
    this.retryCount = 0,
  });

  @override
  Widget build(BuildContext context) {
    final (indicatorColor, tooltip, iconData) = _presentationForStatus();

    return Tooltip(
        message: tooltip,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
          decoration: BoxDecoration(
            color: indicatorColor.withValues(alpha: 0.16),
            border: Border.all(color: indicatorColor, width: 2),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Icon(iconData, color: indicatorColor),
        ),
      
    );
  }

  (Color, String, IconData) _presentationForStatus() {
    switch (status) {
      case ConnectionStatus.connecting:
        return (Colors.orange, 'Connecting...', Icons.wifi_find_outlined);
      case ConnectionStatus.reconnecting:
        final retryLabel = retryCount > 0 ? ' (attempt $retryCount)' : '';
        return (
          Colors.amber.shade700,
          'Reconnecting$retryLabel',
          Icons.autorenew_rounded,
        );
      case ConnectionStatus.connected:
        return (Colors.green, 'Connected', Icons.wifi);
      case ConnectionStatus.disconnected:
        return (Colors.red, 'Not connected', Icons.wifi_off);
    }
  }
}
