import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_home/cubit/control_cubit.dart';
import 'package:smart_home/widget/button.dart';

class RoomWidget extends StatelessWidget {
  final String roomName;
  final List<Map<String, dynamic>> devices;
  final void Function(String deviceName, bool isOn) onChanged;

  const RoomWidget({
    super.key,
    required this.roomName,
    required this.devices,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ControlCubit, ControlState>(
      builder: (context, state) {
        final controlCubit = context.read<ControlCubit>();
        final isInteractive = state.status == ConnectionStatus.connected;

        return GridView.builder(
          padding: const EdgeInsets.all(10),
          physics: const BouncingScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 1.05,
            mainAxisSpacing: 16,
            crossAxisSpacing: 16,
          ),
          itemCount: devices.length,
          itemBuilder: (context, index) {
            final device = devices[index];
            final deviceName = device['name'] as String;
            final currentValue =
                controlCubit.getDeviceState(roomName, deviceName) ??
                (device['status'] as bool? ?? false);

            return Card(
              elevation: 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(24),
              ),
              child: SwitchButton(
                value: currentValue,
                enabled: isInteractive,
                onChanged: (isOn) => onChanged(deviceName, isOn),
                deviceName: deviceName,
                imageOn: device['image_on'] as String?,
                imageOff: device['image_off'] as String?,
              ),
            );
          },
        );
      },
    );
  }
}
