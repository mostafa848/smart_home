import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:wifi_iot/wifi_iot.dart';

class WifiChangeService {
  Future<void> ensureConnected({
    required String ssid,
    required String password,
  }) async {
    final targetSsid = _normalizeSsid(ssid);
    if (targetSsid.isEmpty || (!Platform.isAndroid && !Platform.isIOS)) {
      return;
    }

    await _requestPermissions();

    final currentSsid = await _tryGetCurrentSsid();
    if (currentSsid == targetSsid && await _tryIsConnected()) {
      await _setWifiUsage(true);
      return;
    }

    final connected = await WiFiForIoTPlugin.connect(
      targetSsid,
      password: password.isEmpty ? null : password,
      security: password.isEmpty ? NetworkSecurity.NONE : NetworkSecurity.WPA,
      joinOnce: false,
      withInternet: false,
      timeoutInSeconds: 30,
    );

    final reachedTarget = await _waitForTargetNetwork(targetSsid);
    if (!connected && !reachedTarget) {
      throw Exception('Unable to connect to Wi-Fi network "$targetSsid".');
    }

    await _setWifiUsage(true);
  }

  Future<void> disableWifiUsage() async {
    if (!Platform.isAndroid && !Platform.isIOS) {
      return;
    }

    try {
      await _setWifiUsage(false);
    } catch (error) {
      debugPrint('forceWifiUsage(false) failed: $error');
    }
  }

  Future<void> _requestPermissions() async {
    if (!Platform.isAndroid) {
      return;
    }

    final permissions = <Permission>[
      Permission.locationWhenInUse,
      Permission.nearbyWifiDevices,
    ];

    for (final permission in permissions) {
      final status = await permission.request();
      if (status.isGranted) {
        continue;
      }

      if (permission == Permission.nearbyWifiDevices) {
        throw Exception(
          'Nearby Wi-Fi devices permission is required to join the device network.',
        );
      }

      throw Exception(
        'Location permission is required to read the current Wi-Fi network.',
      );
    }
  }

  Future<bool> _waitForTargetNetwork(String targetSsid) async {
    for (var attempt = 0; attempt < 15; attempt++) {
      final currentSsid = await _tryGetCurrentSsid();
      if (currentSsid == targetSsid) {
        return true;
      }

      if (Platform.isIOS && currentSsid.isEmpty && await _tryIsConnected()) {
        return true;
      }

      await Future.delayed(const Duration(seconds: 1));
    }

    return false;
  }

  Future<void> _setWifiUsage(bool useWifi) async {
    final result = await WiFiForIoTPlugin.forceWifiUsage(useWifi);
    debugPrint('forceWifiUsage($useWifi) => $result');
  }

  String _normalizeSsid(String? ssid) {
    return (ssid ?? '').replaceAll('"', '').trim();
  }

  Future<String> _tryGetCurrentSsid() async {
    try {
      return _normalizeSsid(await WiFiForIoTPlugin.getSSID());
    } catch (error) {
      debugPrint('getSSID failed: $error');
      return '';
    }
  }

  Future<bool> _tryIsConnected() async {
    try {
      return await WiFiForIoTPlugin.isConnected();
    } catch (error) {
      debugPrint('isConnected failed: $error');
      return false;
    }
  }
}
