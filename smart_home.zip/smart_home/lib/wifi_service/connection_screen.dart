import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_home/cubit/control_cubit.dart';
import 'package:smart_home/models/app_memory.dart';

class ConnectionScreen extends StatefulWidget {
  const ConnectionScreen({super.key});

  @override
  State<ConnectionScreen> createState() => _ConnectionScreenState();
}

class _ConnectionScreenState extends State<ConnectionScreen> {
  String _ip = '10.37.100.225';
  int _port = 81;
  String _targetSSID = 'CoreVolt';
  String _targetPassword = 'corevolt123';

  @override
  void initState() {
    super.initState();
    _loadConnectionInfo();
  }

  Future<void> _loadConnectionInfo() async {
    final connectionInfo = await AppMemory().getConnectionInfo();
    if (!mounted || connectionInfo == null) return;

    setState(() {
      _ip = connectionInfo['ip'] as String;
      _port = connectionInfo['port'] as int;
      _targetSSID = connectionInfo['ssid'] as String;
      _targetPassword = connectionInfo['password'] as String;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Connect to System'),
        centerTitle: true,
        elevation: 0,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF000370), Color(0xFF004895), Color(0xFF297EB9)],
          ),
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'اتصل بنظامك الذكي',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w700,
                  color: const Color(0xFF83EEFF),
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 10),
              Text(
                'يرجى إدخال معلومات الاتصال الخاصة بك أدناه',
                style: Theme.of(
                  context,
                ).textTheme.bodyMedium?.copyWith(color: Colors.white70),
                textAlign: TextAlign.end,
              ),
              const SizedBox(height: 24),
              Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(24),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: WiFiConnectionForm(
                    ip: _ip,
                    port: _port,
                    ssid: _targetSSID,
                    password: _targetPassword,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class WiFiConnectionForm extends StatefulWidget {
  final String ip;
  final int port;
  final String ssid;
  final String password;

  const WiFiConnectionForm({
    super.key,
    required this.ip,
    required this.port,
    required this.ssid,
    required this.password,
  });

  @override
  State<WiFiConnectionForm> createState() => _WiFiConnectionFormState();
}

class _WiFiConnectionFormState extends State<WiFiConnectionForm> {
  late final TextEditingController _ipController;
  late final TextEditingController _portController;
  late final TextEditingController _ssidController;
  late final TextEditingController _passwordController;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _ipController = TextEditingController(text: widget.ip);
    _portController = TextEditingController(text: widget.port.toString());
    _ssidController = TextEditingController(text: widget.ssid);
    _passwordController = TextEditingController(text: widget.password);
  }

  @override
  void didUpdateWidget(covariant WiFiConnectionForm oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (widget.ip != oldWidget.ip && _ipController.text != widget.ip) {
      _ipController.text = widget.ip;
    }

    final nextPort = widget.port.toString();
    if (widget.port != oldWidget.port && _portController.text != nextPort) {
      _portController.text = nextPort;
    }

    if (widget.ssid != oldWidget.ssid && _ssidController.text != widget.ssid) {
      _ssidController.text = widget.ssid;
    }

    if (widget.password != oldWidget.password &&
        _passwordController.text != widget.password) {
      _passwordController.text = widget.password;
    }
  }

  @override
  void dispose() {
    _ipController.dispose();
    _portController.dispose();
    _ssidController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _connect() async {
    final ip = _ipController.text.trim();
    final port = int.tryParse(_portController.text.trim());
    final ssid = _ssidController.text.trim();
    final password = _passwordController.text.trim();

    if (!_isValidIpv4(ip) || port == null || port <= 0 || port > 65535) {
      _showSnackBar('Invalid IP address or port', Colors.red);
      return;
    }

    setState(() => _isLoading = true);

    final cubit = context.read<ControlCubit>();
    final isConnected = await cubit.connectWiFi(
      ip,
      port,
      ssid: ssid,
      password: password,
    );

    if (!mounted) return;

    setState(() => _isLoading = false);

    if (isConnected) {
      _showSnackBar('تم الاتصال بنجاح', Colors.green);
      Navigator.pop(context);
      return;
    }

    _showSnackBar('لا يمكن الاتصال ب هذا النظام', Colors.red);
  }

  bool _isValidIpv4(String value) {
    final address = InternetAddress.tryParse(value);
    return address?.type == InternetAddressType.IPv4;
  }

  void _showSnackBar(String message, Color backgroundColor) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: TextStyle(color: Colors.white), textAlign: TextAlign.center),
        backgroundColor: backgroundColor,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        TextField(
          controller: _ssidController,
          enabled: !_isLoading,
          decoration: InputDecoration(
            labelText: 'Wi-Fi SSID',
            prefixIcon: const Icon(Icons.wifi),
            hintText: 'MyNetwork',
          ),
        ),
        const SizedBox(height: 16),
        TextField(
          controller: _passwordController,
          enabled: !_isLoading,
          obscureText: true,
          decoration: InputDecoration(
            labelText: 'Wi-Fi Password',
            prefixIcon: const Icon(Icons.lock),
            hintText: '••••••••',
          ),
        ),
        const SizedBox(height: 16),
        TextField(
          controller: _ipController,
          enabled: !_isLoading,
          decoration: InputDecoration(
            labelText: 'System IP Address',
            prefixIcon: const Icon(Icons.computer),
            hintText: '192.168.1.100',
          ),
          keyboardType: TextInputType.url,
          autofillHints: const [AutofillHints.email],
        ),
        const SizedBox(height: 16),
        TextField(
          controller: _portController,
          enabled: !_isLoading,
          decoration: InputDecoration(
            labelText: 'WebSocket Port',
            prefixIcon: const Icon(Icons.settings_ethernet),
            hintText: '81',
          ),
          keyboardType: TextInputType.number,
          autofillHints: const [AutofillHints.email],
        ),
        const SizedBox(height: 16),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            icon: _isLoading
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: Colors.white,
                    ),
                  )
                : const Icon(Icons.wifi),
            label: Text(_isLoading ? 'Connecting...' : 'Connect to Wi-Fi'),
            onPressed: _isLoading ? null : _connect,
          ),
        ),
      ],
    );
  }
}
