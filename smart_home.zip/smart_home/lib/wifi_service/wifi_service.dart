import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:web_socket_channel/io.dart';

class WiFiService {
  IOWebSocketChannel? _channel;
  StreamSubscription<dynamic>? _subscription;
  bool _isConnected = false;

  String? lastIP;
  int? lastPort;
  String? lastSSID;
  String? lastPassword;

  void Function(Map<String, dynamic>)? onJsonMessage;
  void Function(Object? error)? onConnectionClosed;

  bool get isConnected => _isConnected && _channel != null;

  Future<void> connect(
    String ip,
    int port,
    String ssid,
    String password,
  ) async {
    lastIP = ip;
    lastPort = port;
    lastSSID = ssid;
    lastPassword = password;

    try {
      await disconnect();

      final socket = await WebSocket.connect(
        'ws://$ip:$port/',
      ).timeout(const Duration(seconds: 5));

      _channel = IOWebSocketChannel(socket);
      _isConnected = true;

      _subscription = _channel!.stream.listen(
        _handleIncomingData,
        onError: (Object error, StackTrace stackTrace) {
          _handleConnectionClosed(error);
        },
        onDone: () {
          _handleConnectionClosed();
        },
        cancelOnError: true,
      );
    } catch (e) {
      await disconnect();
      debugPrint('Connection error: $e ip: $ip, port: $port');
      rethrow;
    }
  }

  void send(Map<String, dynamic> data) {
    if (!isConnected) return;

    final msg = jsonEncode(data);
    _channel!.sink.add(msg);
    debugPrint('Sent JSON: $msg');
  }

  void _handleIncomingData(dynamic data) {
    final raw = data?.toString();
    if (raw == null) return;

    try {
      final decoded = json.decode(raw);
      if (decoded is Map<String, dynamic>) {
        debugPrint('JSON: $decoded');
        onJsonMessage?.call(decoded);
      } else {
        debugPrint('Message is not a JSON object: $decoded');
      }
    } catch (e) {
      debugPrint('JSON parse error: $e');
    }
  }

  void _handleConnectionClosed([Object? error]) {
    if (!isConnected && _subscription == null) return;

    _isConnected = false;
    _subscription = null;
    _channel = null;

    debugPrint('WebSocket closed${error != null ? ': $error' : ''}');
    onConnectionClosed?.call(error);
  }

  Future<void> disconnect() async {
    _isConnected = false;
    await _subscription?.cancel();
    _subscription = null;
    await _channel?.sink.close();
    _channel = null;
  }
}
