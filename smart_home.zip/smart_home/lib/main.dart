import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_home/widget/custom_drawer.dart';
import 'package:smart_home/widget/room.dart';
import 'package:smart_home/widget/connection_indicator.dart';
import 'package:smart_home/cubit/control_cubit.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => ControlCubit()..reconnectToLastConnection(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Core Volt',
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF297EB9),
            brightness: Brightness.dark,
            surface: const Color(0xFF062F6E),
            primary: const Color(0xFF297EB9),
            secondary: const Color(0xFF55B5DC),
            onPrimary: Colors.white,
            onSecondary: Colors.white,
            onSurface: Colors.white,
          ),
          scaffoldBackgroundColor: const Color(0xFF000370),
          appBarTheme: const AppBarTheme(
            backgroundColor: Color(0xFF004895),
            foregroundColor: Colors.white,
            elevation: 0,
            centerTitle: false,
          ),
          drawerTheme: const DrawerThemeData(
            backgroundColor: Color(0xFF062F6E),
          ),
          cardTheme: CardThemeData(
            color: const Color(0xFF0D3A75),
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
          ),
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF55B5DC),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              padding: const EdgeInsets.symmetric(vertical: 16),
            ),
          ),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: const Color(0xFF0D3A75),
            contentPadding: const EdgeInsets.symmetric(
              vertical: 18,
              horizontal: 20,
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: const BorderSide(color: Color(0xFF83EEFF)),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide(color: Colors.white24),
            ),
            labelStyle: const TextStyle(color: Colors.white70),
            hintStyle: const TextStyle(color: Colors.white38),
          ),
        ),
        home: const HomePage(),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage>
    with SingleTickerProviderStateMixin {
  late Future<Map<String, dynamic>> futureData;
  TabController? _tabController;
  List<dynamic> rooms = [];
  late String userName = "User Name";

  @override
  void initState() {
    super.initState();
    futureData = loadData();
  }

  Future<Map<String, dynamic>> loadData() async {
    try {
      final String response = await rootBundle.loadString('assets/data.json');
      final Map<String, dynamic> jsonData = json.decode(response);
      userName = jsonData['userName'] as String;
      setState(() {});
      return jsonData;
    } catch (e) {
      debugPrint('Error loading JSON: $e');
      throw Exception('Failed to load data: $e');
    }
  }

  @override
  void dispose() {
    _tabController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

    return Scaffold(
      key: scaffoldKey,
      endDrawer: CustomDrawer(), // Use the custom drawer here
      appBar: AppBar(
        title: Row(
          children: [
            Image.asset('assets/Logo.png', width: 56, height: 56),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'CoreVolt',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    "Smart Home",
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w300,
                    ),
                  ),
                ],
              ),
            ),
            BlocBuilder<ControlCubit, ControlState>(
              builder: (context, state) {
                return ConnectionIndicator(
                  status: state.status,
                  retryCount: state.retryCount,
                );
              },
            ),
          ],
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF000370), Color(0xFF004895), Color(0xFF297EB9)],
          ),
        ),
        child: SafeArea(
          child: FutureBuilder<Map<String, dynamic>>(
            future: futureData,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(
                  child: CircularProgressIndicator(color: Color(0xFF83EEFF)),
                );
              } else if (snapshot.hasError) {
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(
                          Icons.error_outline,
                          size: 56,
                          color: Color(0xFF83EEFF),
                        ),
                        const SizedBox(height: 18),
                        Text(
                          'Error loading configuration',
                          style: Theme.of(context).textTheme.titleMedium,
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          snapshot.error.toString(),
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.white70),
                        ),
                        const SizedBox(height: 20),
                        ElevatedButton(
                          onPressed: () {
                            setState(() {
                              futureData = loadData();
                            });
                          },
                          child: const Text('Retry'),
                        ),
                      ],
                    ),
                  ),
                );
              }
              final data = snapshot.data!;
              rooms = data['rooms'] as List<dynamic>;
              _tabController ??= TabController(
                length: rooms.length,
                vsync: this,
              );
              return Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 10,
                ),
                child: Column(
                  children: [
                    const SizedBox(height: 8),
                    Container(
                      decoration: BoxDecoration(
                        color: const Color(0xFF062F6E),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: TabBar(
                        dividerHeight: 0,
                        controller: _tabController,
                        isScrollable: true,
                        labelColor: const Color(0xFF83EEFF),
                        unselectedLabelColor: Colors.white70,
                        tabs: rooms.map((room) {
                          final roomMap = room as Map<String, dynamic>;
                          return roomMap['image'] == null
                              ? Tab(
                                  text: roomMap['name'] as String,
                                  icon: _getIconForRoom(roomMap['name']),
                                )
                              : Tab(
                                  child: Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(5),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.blue.withOpacity(0.3),
                                          blurRadius: 8,
                                          spreadRadius: 1,
                                        ),
                                      ],
                                    ),
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(5),
                                      child: Stack(
                                        children: [
                                          Image.asset(
                                            roomMap['image'],
                                            width: 64,
                                            height: 56,
                                            fit: BoxFit.cover,
                                            errorBuilder:
                                                (context, error, stackTrace) =>
                                                    _getIconForRoom(
                                                      roomMap['name'] as String,
                                                    ),
                                          ),

                                          // نص مع خلفية بلورية
                                          Positioned(
                                            bottom: 16,
                                            left: 0,
                                            right: 0,
                                            child: Text(
                                              roomMap['name'] as String,
                                              textAlign: TextAlign.center,
                                              style: const TextStyle(
                                                color: Colors.white70,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 10,
                                                letterSpacing: 0.5,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                );
                        }).toList(),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Expanded(
                      child: TabBarView(
                        controller: _tabController,
                        children: rooms.map((room) {
                          final roomMap = room as Map<String, dynamic>;
                          return RoomWidget(
                            roomName: roomMap['name'] as String,
                            devices: List<Map<String, dynamic>>.from(
                              roomMap['devices'] as List<dynamic>,
                            ),
                            onChanged: (String deviceName, bool value) {
                              debugPrint(
                                '{ user : $userName, Room: ${roomMap['name']}, device name: $deviceName, state: $value}',
                              );

                              final command = {
                                'user': userName,
                                'room': roomMap['name'],
                                'device': deviceName,
                                'state': value,
                              };

                              context.read<ControlCubit>().sendCommand(command);
                            },
                          );
                        }).toList(),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  Icon _getIconForRoom(String roomName) {
    switch (roomName.toLowerCase()) {
      case 'living room':
        return Icon(Icons.home);
      case 'bedroom':
        return Icon(Icons.bed);
      case 'kitchen':
        return Icon(Icons.kitchen);
      case 'bathroom':
        return Icon(Icons.bathtub);
      default:
        return Icon(Icons.room);
    }
  }
}
