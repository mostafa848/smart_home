# Smart Home Documentation

هذه الوثائق تشرح المشروع الحالي كما هو موجود في الكود الآن، وليس كما يفترض أن يكون.
الهدف منها أن تسهل عليك تعديل الواجهة، منطق التحكم، أو طبقة الاتصال بدون الحاجة إلى إعادة فهم المشروع من الصفر كل مرة.

## ترتيب القراءة المقترح

1. `architecture.md`
2. `technical-flow.md`
3. `code-map.md`
4. `modification-guide.md`
5. `platform-notes.md`

## ملخص سريع

- التطبيق مبني بـ Flutter ويعرض غرفًا وأجهزة يتم تحميلها من `assets/data.json`.
- كل عمليات الاتصال والتحكم تمر عبر `ControlCubit`.
- التطبيق لا يتصل فقط بـ WebSocket، بل يحاول أيضًا تحويل الهاتف إلى شبكة الـ Wi-Fi التي يدخلها المستخدم قبل فتح الـ WebSocket.
- حالة الأجهزة داخل الواجهة تعتمد على `deviceStates` داخل `ControlState`.
- آخر إعدادات اتصال ناجحة تحفظ محليًا باستخدام `SharedPreferences`.

## خريطة سريعة للمجلدات

```text
lib/
  main.dart                  نقطة دخول التطبيق + HomePage + الثيم
  cubit/
    control_cubit.dart       منطق الاتصال والتحكم والمزامنة
    control_state.dart       نموذج الحالة العامة
  wifi_service/
    wifi_service.dart        WebSocket فقط
    wifi_change.dart         تغيير شبكة الهاتف إلى Wi-Fi المستهدف
    connection_screen.dart   شاشة إدخال بيانات الاتصال
  models/
    app_memory.dart          حفظ واسترجاع آخر إعدادات اتصال
  widget/
    room.dart                عرض شبكة الأجهزة داخل كل غرفة
    button.dart              زر الجهاز القابل للتبديل
    connection_indicator.dart مؤشر حالة الاتصال
    custom_drawer.dart       القائمة الجانبية

assets/
  data.json                  تعريف المستخدم والغرف والأجهزة
  Logo.png                   شعار التطبيق
  light_on.png/off.png       أصول معرفة فعليًا في pubspec

docs/
  README.md
  architecture.md
  technical-flow.md
  code-map.md
  modification-guide.md
  platform-notes.md
  diagrams/
    component-flow.mmd
    control-state.mmd
```

## أهم 5 ملفات لفهم المشروع بسرعة

1. `lib/main.dart`
2. `lib/cubit/control_cubit.dart`
3. `lib/wifi_service/wifi_change.dart`
4. `lib/wifi_service/wifi_service.dart`
5. `assets/data.json`

## ملاحظات مهمة قبل أي تعديل

- `assets/data.json` هو المصدر الرئيسي لبناء الغرف والأجهزة، لكنه يحتوي حاليًا على بيانات غير مثالية.
- يوجد تكرار في أسماء الغرف والأجهزة، وهذا قد يسبب تصادمًا في مفاتيح الحالة.
- كثير من الصور المشار إليها داخل `data.json` غير موجودة فعليًا داخل `assets/` أو غير معلنة في `pubspec.yaml`.
- ملف الاختبار الحالي `test/widget_test.dart` هو اختبار Flutter الافتراضي للعداد، ولا يعبر عن التطبيق الحالي.
- بعض الوثائق السابقة كانت قديمة أو بترميز غير واضح، لذلك تم استبدالها بهذه النسخة.

## أين أبدأ لو أردت التعديل؟

- تعديل شكل الصفحة الرئيسية: `lib/main.dart`
- تعديل طريقة عرض الأجهزة: `lib/widget/room.dart` و `lib/widget/button.dart`
- تعديل منطق الإرسال والاستقبال: `lib/cubit/control_cubit.dart`
- تعديل الاتصال بالشبكة أو إعادة الاتصال: `lib/wifi_service/`
- تعديل بنية الغرف والأجهزة: `assets/data.json`

