# Technical Flow

## 1. تشغيل التطبيق

عند تشغيل التطبيق يبدأ التنفيذ من `main()` داخل `lib/main.dart`.

الذي يحدث:

1. إنشاء `MyApp`.
2. إنشاء `BlocProvider`.
3. إنشاء `ControlCubit`.
4. استدعاء `reconnectToLastConnection()` مباشرة بعد إنشاء الـ Cubit.

هذا يعني أن التطبيق يحاول استعادة آخر اتصال ناجح بمجرد الفتح، إذا كانت البيانات محفوظة.

## 2. تحميل الصفحة الرئيسية

داخل `HomePage`:

1. يستدعي `loadData()`.
2. يقرأ `assets/data.json`.
3. يستخرج `userName`.
4. يبني `TabBar` و `TabBarView` من `rooms`.

### ملاحظة مهمة

`_tabController` يتم إنشاؤه مرة واحدة فقط باستخدام:

- `rooms.length`

إذا تغير عدد الغرف أثناء التشغيل فلن يعاد إنشاء الـ Controller تلقائيًا.

## 3. تدفق الاتصال اليدوي

عندما يفتح المستخدم شاشة الاتصال:

- `CustomDrawer` ينقل إلى `ConnectionScreen`
- `ConnectionScreen` يحمل آخر بيانات محفوظة من `AppMemory`
- `WiFiConnectionForm` يعرض الحقول للمستخدم

عند الضغط على زر الاتصال:

1. يتم التحقق من صحة الـ IP والـ port.
2. يستدعى `ControlCubit.connectWiFi(...)`.
3. يضبط الـ Cubit الحالة إلى `connecting`.
4. إذا كان `ssid` موجودًا:
   يتم استدعاء `WifiChangeService.ensureConnected(...)`.
5. بعد نجاح تغيير شبكة الهاتف:
   يتم استدعاء `WiFiService.connect(...)`.
6. إذا نجح WebSocket:
   يتم حفظ بيانات الاتصال في `AppMemory`.
7. يتم تحويل الحالة إلى `connected`.

## 4. تدفق الاتصال التلقائي عند فتح التطبيق

عند بدء التطبيق:

1. `ControlCubit.reconnectToLastConnection()` يقرأ:
   - `ip`
   - `port`
   - `ssid`
   - `password`
2. إذا لم يجد بيانات محفوظة ينتهي بصمت.
3. إذا وجد بيانات:
   يستدعي `connectWiFi(..., isReconnect: true)`.
4. إذا فشل الاتصال:
   يتم جدولة إعادة المحاولة بعد 3 ثوان.

## 5. تدفق إعادة الاتصال

إذا انقطع WebSocket بشكل غير يدوي:

1. `WiFiService` يستدعي `onConnectionClosed`.
2. `ControlCubit._handleConnectionClosed(...)` يعمل.
3. تتحول الحالة إلى `disconnected` مؤقتًا.
4. بعدها يستدعي `_scheduleReconnect(...)`.
5. ترتفع `retryCount`.
6. بعد 3 ثوان يعاد استدعاء `connectWiFi(...)`.

### كيف يعرف الـ Cubit ماذا يعيد استخدامه؟

`WiFiService` يحتفظ داخليًا بآخر:

- `lastIP`
- `lastPort`
- `lastSSID`
- `lastPassword`

وبذلك تكون محاولة إعادة الاتصال معتمدة على آخر اتصال فعلي وليس فقط على قيم الواجهة.

## 6. تدفق إرسال أمر جهاز

عند الضغط على جهاز داخل الغرفة:

1. `SwitchButton` ينفذ `onChanged`.
2. `RoomWidget` يمرر اسم الجهاز والقيمة الجديدة.
3. `HomePage` يبني الأمر بهذا الشكل:

```json
{
  "user": "mostafa",
  "room": "Living Room",
  "device": "TV",
  "state": true
}
```

4. يستدعي `ControlCubit.sendCommand(...)`.
5. إذا لم تكن الحالة `connected` فلن يرسل شيئًا.
6. إذا كانت الحالة `connected`:
   - يحدث الحالة محليًا عبر `syncDeviceState`
   - ثم يرسل JSON عبر WebSocket

### لماذا يحدث الحالة محليًا قبل الرد؟

هذا يعطي الواجهة استجابة أسرع، لكن يعني أيضًا أن الواجهة قد تعرض الحالة الجديدة قبل أن يؤكدها النظام الخارجي.

## 7. تدفق استقبال الرسائل

الرسالة الواردة تمر بهذه المراحل:

1. `WiFiService._handleIncomingData`
2. تحويل النص إلى JSON
3. تمرير `Map<String, dynamic>` إلى `ControlCubit._handleMessage`
4. محاولة استخراج تحديث حالة جهاز عبر `_tryApplyDeviceStates`

## 8. أشكال الرسائل التي يفهمها `ControlCubit`

الـ Cubit يحاول فهم أكثر من شكل:

### تحديث مباشر

```json
{
  "room": "Living Room",
  "device": "TV",
  "state": true
}
```

### تحديث داخل `payload`

```json
{
  "type": "update",
  "payload": {
    "roomName": "Living Room",
    "deviceName": "TV",
    "status": "on"
  }
}
```

### قائمة أجهزة

```json
{
  "devices": [
    {"room": "Living Room", "device": "TV", "state": true},
    {"room": "Kitchen", "device": "Oven", "state": false}
  ]
}
```

### رسالة خطأ

```json
{
  "type": "error",
  "message": "Invalid command"
}
```

## 9. كيف يستخرج `ControlCubit` الحالة من الرسالة؟

الدالة `_extractDeviceUpdate` مرنة نسبيًا، وتقرأ:

- اسم الغرفة من:
  - `room`
  - `roomName`
  - `room_name`
- اسم الجهاز من:
  - `device`
  - `deviceName`
  - `device_name`
  - أو `device.name`
- الحالة من:
  - `state`
  - `status`
  - `isOn`
  - `value`
  - أو الحقول نفسها داخل `device`

كما أنها تحول القيم التالية إلى `bool`:

- `true` / `false`
- `1` / `0`
- `on` / `off`

## 10. المفتاح الداخلي لحالة الجهاز

كل جهاز داخل `deviceStates` يخزن بمفتاح:

```text
roomName.toLowerCase() + "::" + deviceName.toLowerCase()
```

مثال:

```text
living room::tv
```

### أثر ذلك

إذا كان لديك:

- غرفتان بالاسم نفسه
- أو جهازان بالاسم نفسه داخل الغرفة نفسها

فإن حالتهما ستتداخل.

## 11. الحفظ المحلي

`AppMemory` يحفظ:

- `System_ip`
- `System_port`
- `System_ssid`
- `System_password`

ولا يوجد حاليًا:

- تشفير لكلمة المرور
- سجل اتصالات
- أكثر من ملف اتصال واحد

