# Modification Guide

## 1. إذا أردت إضافة غرفة جديدة

عدّل:

- `assets/data.json`

أضف عنصرًا جديدًا داخل `rooms`.

مثال:

```json
{
  "name": "Office",
  "devices": [
    {
      "name": "PC",
      "status": false,
      "image_on": "assets/pc_on.png",
      "image_off": "assets/pc_off.png"
    }
  ]
}
```

ثم تأكد من:

- وجود الصور داخل `assets/`
- إضافة هذه الصور إلى `pubspec.yaml` إذا كنت ستعتمدها رسميًا

## 2. إذا أردت إضافة جهاز جديد داخل غرفة

عدّل:

- `assets/data.json`

لكن انتبه جدًا:

- لا تكرر `name` داخل الغرفة نفسها إذا كنت ستعتمد الحالة الحالية للمشروع.

### لماذا؟

لأن مفتاح الحالة يعتمد على:

```text
roomName::deviceName
```

فإذا كررت اسم الجهاز ستتشارك العناصر الحالة نفسها.

## 3. إذا أردت حل مشكلة تكرار الأسماء مستقبلًا

الحل الأفضل هو إضافة معرف فريد لكل جهاز، مثل:

```json
{
  "id": "bedroom-fan-1",
  "name": "Fan",
  "status": false
}
```

ثم تعديل:

- `assets/data.json`
- `lib/widget/room.dart`
- `lib/main.dart`
- `lib/cubit/control_cubit.dart`

بحيث يعتمد `deviceStates` على `deviceId` بدل `roomName::deviceName`.

## 4. إذا أردت تغيير شكل الأمر المرسل للنظام

الملف الأهم:

- `lib/main.dart`

لأن الأمر يبنى حاليًا داخل callback الخاصة بـ `RoomWidget`.

الشكل الحالي:

```dart
final command = {
  'user': userName,
  'room': roomMap['name'],
  'device': deviceName,
  'state': value,
};
```

إذا أردت إضافة حقول مثل:

- `deviceId`
- `timestamp`
- `commandType`

فهذا هو أول مكان تعدله.

بعدها راجع:

- `lib/cubit/control_cubit.dart`
- منطق النظام الخارجي الذي يستقبل الرسالة

## 5. إذا أردت تغيير طريقة فهم الرسائل الواردة

عدّل:

- `lib/cubit/control_cubit.dart`

وبالأخص:

- `_handleMessage`
- `_tryApplyDeviceStates`
- `_extractDeviceUpdate`
- `_coerceBool`

هذه هي المنطقة الصحيحة إذا أردت دعم:

- مفاتيح جديدة
- تنسيق مختلف للرسائل
- رسائل bulk update
- رسائل acknowledgment أكثر تفصيلًا

## 6. إذا أردت تغيير شاشة الاتصال

عدّل:

- `lib/wifi_service/connection_screen.dart`

هناك ستجد:

- القيم الافتراضية
- شكل الحقول
- التحقق من البيانات
- رسائل النجاح والخطأ

## 7. إذا أردت تغيير استراتيجية الاتصال بالشبكة

عدّل:

- `lib/wifi_service/wifi_change.dart`

هذا هو المكان المناسب لتغيير:

- مدة الانتظار
- طريقة التحقق من الـ SSID
- آلية طلب الصلاحيات
- `joinOnce`
- `withInternet`
- سلوك `forceWifiUsage`

## 8. إذا أردت تغيير WebSocket نفسه

عدّل:

- `lib/wifi_service/wifi_service.dart`

هناك يمكنك تعديل:

- مهلة الاتصال
- عنوان الـ WebSocket
- طريقة parse الرسائل
- أسلوب التعامل مع الإغلاق أو الخطأ

## 9. إذا أردت تغيير ما يتم حفظه محليًا

عدّل:

- `lib/models/app_memory.dart`

ثم راجع أيضًا:

- `lib/wifi_service/connection_screen.dart`
- `lib/cubit/control_cubit.dart`

لأن الحقول الجديدة يجب أن:

1. تحفظ
2. تستعاد
3. تملأ في النموذج
4. تستخدم عند إعادة الاتصال

## 10. إذا أردت تغيير شكل الصفحة الرئيسية أو الثيم

ابدأ من:

- `lib/main.dart`

لأن هذا الملف يحتوي:

- `ThemeData`
- `AppBarTheme`
- `InputDecorationTheme`
- ألوان الخلفية والتدرجات

## 11. إذا أردت تعديل القائمة الجانبية

عدّل:

- `lib/widget/custom_drawer.dart`

ستحتاج غالبًا لتعديل:

- روابط السوشال
- معلومات الدعم
- رقم نسخة النظام
- شاشة الاتصال

## 12. إذا أردت إضافة اختبارات حقيقية

ابدأ باستبدال:

- `test/widget_test.dart`

بأنواع اختبارات مناسبة مثل:

- اختبار `ControlCubit` بوحدات منفصلة
- اختبار تحميل `data.json`
- اختبار `RoomWidget`
- اختبار `ConnectionScreen`

## 13. مشاكل حالية يجب معرفتها أثناء التعديل

### تكرار الغرف والأجهزة

حاليًا يوجد:

- غرف مكررة باسم `Bedroom`
- أجهزة مكررة باسم `Fan` و `Heater`

هذا يجعل الحالة قد تتداخل بين عناصر مختلفة.

### الأصول غير المتطابقة

الـ JSON يشير إلى صور مثل:

- `assets/tv_on.png`
- `assets/fan_on.png`
- `assets/heater_on.png`

لكن هذه الصور ليست ظاهرة حاليًا داخل `assets/` المعلن عنها في المشروع.

النتيجة:

- الواجهة لن تنهار
- لكن ستظهر أيقونة بديلة بدل الصور

### `numberOfRooms` غير مستخدم

تغييره لن يؤثر على الواجهة الحالية.

### الاختبارات الحالية مضللة

ملف الاختبار الحالي يخص مشروع العداد الافتراضي، وليس هذا التطبيق.

## 14. مسار تعديل آمن مقترح

عند تنفيذ أي تعديل متوسط أو كبير:

1. عدّل الوثيقة المناسبة في `docs/` إذا تغير السلوك.
2. عدّل الكود.
3. راجع `assets/data.json` إذا كان التعديل يخص الغرف أو الأجهزة.
4. راجع `pubspec.yaml` إذا أضفت صورًا أو حزمًا.
5. راجع `platform-notes.md` إذا كان التعديل يخص الاتصال أو الصلاحيات.

