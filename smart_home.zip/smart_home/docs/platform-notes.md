# Platform Notes

## Android

الملف الأساسي:

- `android/app/src/main/AndroidManifest.xml`

### الصلاحيات المستخدمة

- `ACCESS_FINE_LOCATION`
- `ACCESS_COARSE_LOCATION`
- `NEARBY_WIFI_DEVICES`
- `CHANGE_WIFI_STATE`
- `ACCESS_WIFI_STATE`
- `INTERNET`

### لماذا هذه الصلاحيات؟

- قراءة أو التفاعل مع شبكات Wi-Fi
- السماح للتطبيق بالاتصال بالشبكة المحلية
- دعم الأجهزة الحديثة التي تتطلب `NEARBY_WIFI_DEVICES`

### ملاحظة مهمة

المشروع يستخدم:

```text
ws://ip:port/
```

ولذلك تم تفعيل:

- `android:usesCleartextTraffic="true"`

بدون هذا قد يفشل الاتصال غير المشفر على بعض الإعدادات.

## iOS

الملفات الأساسية:

- `ios/Runner/Info.plist`
- `ios/Runner/Runner.entitlements`

### ما تم تفعيله؟

- `NSLocalNetworkUsageDescription`
- `NSLocationWhenInUseUsageDescription`
- `com.apple.developer.networking.HotspotConfiguration`

### لماذا هذا مهم؟

لأن التطبيق يحتاج:

- الوصول إلى الشبكة المحلية
- قراءة حالة الشبكة الحالية في بعض السيناريوهات
- طلب الانضمام إلى شبكة Wi-Fi عبر النظام

## قيود iOS التي يجب توقعها

- الاتصال بالشبكة قد لا يكون صامتًا 100%.
- النظام قد يطلب موافقة المستخدم.
- التحقق من اسم الشبكة الحالية قد لا يكون متاحًا دائمًا بالشكل نفسه على كل إصدار.

لهذا السبب يتعامل `WifiChangeService` بحذر مع:

- فشل `getSSID()`
- فشل `isConnected()`
- التأخير في انتقال الهاتف إلى الشبكة الجديدة

## قيود Android التي يجب توقعها

تغيير الشبكة على Android ليس موحدًا تمامًا بين الإصدارات.
سلوك الاتصال قد يختلف حسب:

- إصدار النظام
- الشركة المصنعة
- سياسة النظام الخاصة بالـ Wi-Fi

## ملاحظات عن الحزم

### `wifi_iot`

تستخدم من أجل:

- الاتصال بالشبكة
- معرفة الـ SSID الحالي
- توجيه حركة التطبيق عبر الشبكة المطلوبة

### `permission_handler`

تستخدم من أجل:

- طلب صلاحيات الموقع
- طلب `Nearby Wi-Fi Devices` على Android

## ماذا أراجع إذا توقف الاتصال؟

ابدأ بهذا الترتيب:

1. `lib/wifi_service/wifi_change.dart`
2. `lib/wifi_service/wifi_service.dart`
3. `lib/cubit/control_cubit.dart`
4. `android/app/src/main/AndroidManifest.xml`
5. `ios/Runner/Info.plist`
6. `ios/Runner/Runner.entitlements`

## ماذا أراجع إذا توقف ظهور الصور؟

افحص:

1. `assets/data.json`
2. وجود الملفات فعليًا داخل `assets/`
3. إدراج الملفات في `pubspec.yaml`

## ماذا أراجع إذا تغيرت بنية الرسائل من الجهاز الخارجي؟

افحص:

1. `lib/cubit/control_cubit.dart`
2. `_extractDeviceUpdate`
3. `_coerceBool`
4. منطق الرسائل في النظام الخارجي نفسه

