# Architecture

## فكرة المشروع

هذا التطبيق هو واجهة تحكم منزل ذكي تتصل بوحدة خارجية عبر WebSocket على شبكة محلية.
المستخدم يدخل:

- اسم شبكة الـ Wi-Fi
- كلمة المرور
- عنوان الـ IP
- رقم المنفذ `port`

بعدها يحاول التطبيق:

1. تحويل الهاتف إلى شبكة الـ Wi-Fi المطلوبة.
2. توجيه حركة التطبيق عبر تلك الشبكة.
3. فتح اتصال WebSocket مع النظام الخارجي.
4. إرسال أوامر التحكم واستقبال تحديثات الحالة.

## الطبقات الأساسية

### 1. طبقة العرض UI

تشمل:

- `HomePage` في `lib/main.dart`
- `RoomWidget` في `lib/widget/room.dart`
- `SwitchButton` في `lib/widget/button.dart`
- `ConnectionIndicator` في `lib/widget/connection_indicator.dart`
- `ConnectionScreen` في `lib/wifi_service/connection_screen.dart`
- `CustomDrawer` في `lib/widget/custom_drawer.dart`

هذه الطبقة لا يجب أن تعرف تفاصيل WebSocket أو SharedPreferences بشكل مباشر.
هي فقط تعرض البيانات وترسل نوايا المستخدم إلى `ControlCubit`.

### 2. طبقة الحالة والمنطق

الملف المركزي هنا هو:

- `lib/cubit/control_cubit.dart`

وهو مسؤول عن:

- بدء الاتصال
- إعادة الاتصال التلقائي
- تخزين آخر بيانات اتصال
- استقبال الرسائل من النظام الخارجي
- تحويل الرسائل إلى حالة قابلة للعرض في الواجهة
- إرسال أوامر التحكم

### 3. طبقة الخدمات

- `wifi_service.dart`
  مسؤول فقط عن WebSocket.
- `wifi_change.dart`
  مسؤول عن تحويل شبكة الهاتف إلى شبكة الـ Wi-Fi التي أدخلها المستخدم.
- `app_memory.dart`
  مسؤول عن الحفظ المحلي لآخر إعدادات الاتصال.

### 4. طبقة المنصة

تشمل ملفات Android و iOS التي تمنح:

- صلاحيات الـ Wi-Fi
- صلاحيات الشبكة المحلية
- إعدادات الاتصال غير المشفر `ws://`
- صلاحيات `HotspotConfiguration` على iOS

## التبعيات الأساسية بين الملفات

```mermaid
flowchart LR
  A[main.dart] --> B[ControlCubit]
  A --> C[HomePage]
  C --> D[RoomWidget]
  C --> E[ConnectionIndicator]
  C --> F[CustomDrawer]
  F --> G[ConnectionScreen]
  G --> B
  D --> B
  B --> H[WifiChangeService]
  B --> I[WiFiService]
  B --> J[AppMemory]
  I --> K[ESP32 / Smart Home Controller]
```

## حالة التطبيق العامة

الحالة العامة معرفة في `ControlState` وتتكون من:

- `status`
- `errorMessage`
- `retryCount`
- `deviceStates`

### معنى الحقول

- `status`
  حالة الاتصال العامة.
- `errorMessage`
  آخر رسالة خطأ أو وصف لمشكلة اتصال.
- `retryCount`
  عدد محاولات إعادة الاتصال.
- `deviceStates`
  خريطة لحالة الأجهزة المفعل/غير مفعل داخل الواجهة.

### قيم `ConnectionStatus`

- `connecting`
- `reconnecting`
- `connected`
- `disconnected`

## لماذا `ControlCubit` هو محور المشروع؟

لأن كل شيء تقريبًا يمر منه:

- الواجهة تطلب منه الاتصال.
- الواجهة تطلب منه إرسال أمر.
- خدمة WebSocket ترجع له الرسائل.
- خدمة تغيير الشبكة تستخدم قبل الاتصال.
- خدمة التخزين تستخدم لحفظ واسترجاع آخر اتصال ناجح.

هذا يجعل `ControlCubit` أفضل مكان عند تعديل:

- بروتوكول الرسائل
- استراتيجية إعادة الاتصال
- طريقة مزامنة حالات الأجهزة
- قواعد السماح/المنع قبل الإرسال

## مصدر بناء الواجهة

الصفحة الرئيسية لا تبني الغرف من كود ثابت، بل من `assets/data.json`.
هذا يعني أن إضافة غرف وأجهزة غالبًا تبدأ من JSON وليس من الواجهة مباشرة.

لكن مهم جدًا:

- التطبيق يستخدم `rooms.length` وليس `numberOfRooms`.
- حالة الجهاز تعتمد على `roomName + deviceName`.
- لذلك تكرار الأسماء قد يسبب تصادم حالة.

## مخططات إضافية

- المخطط العام: `docs/diagrams/component-flow.mmd`
- مخطط حالات الاتصال: `docs/diagrams/control-state.mmd`

