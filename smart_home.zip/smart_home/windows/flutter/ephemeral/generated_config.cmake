# Generated code do not commit.
file(TO_CMAKE_PATH "C:\\flutter_windows_3.38.7-stable\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\Users\\mosta\\Desktop\\smart_home" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.1+2" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 1 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 2 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=C:\\flutter_windows_3.38.7-stable\\flutter"
  "PROJECT_DIR=C:\\Users\\mosta\\Desktop\\smart_home"
  "FLUTTER_ROOT=C:\\flutter_windows_3.38.7-stable\\flutter"
  "FLUTTER_EPHEMERAL_DIR=C:\\Users\\mosta\\Desktop\\smart_home\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\Users\\mosta\\Desktop\\smart_home"
  "FLUTTER_TARGET=C:\\Users\\mosta\\Desktop\\smart_home\\lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9WRVJTSU9OPTMuNDEuNA==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049ZmYzN2JlZjYwMw==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049ZTRiOGRjYTNmMQ==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMS4x"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=C:\\Users\\mosta\\Desktop\\smart_home\\.dart_tool\\package_config.json"
)
